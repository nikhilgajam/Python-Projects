Copyright Bluemoon Interactive (http://www.bluemoon.ee/)

Distribution
------------
This program is freeware. You can distribute this program freely, as
long as you don't reverse engineer, and/or modify this program or
any of its accompanying files. This program must be distributed as
a single unit, with all accompanying files included and intact in
their original form.

Disclaimer
----------
This program is distributed "as-is" and no warranty is granted
or implied. Bluemoon Interactive will not be held responsible for
any damage that the use of this program may cause to any individual
or organization. It is completely at your own risk to use this
software.
