from django.shortcuts import render
from .models import Contact
import urllib.request
import json


# Create your views here.
def index(request):
    if request.method == "POST":
        first_name = request.POST.get('firstname')
        last_name = request.POST.get('lastname')
        x = urllib.request.urlopen("http://api.icndb.com/jokes/random?firstName=" + first_name + "&lastName=" + last_name)
        json_data = json.loads(x.read())
        joke = json_data['value']['joke']
        context = {'joke': joke}
        return render(request, 'index/index.html', context)
    else:
        first_name = "Nikhil"
        last_name = ""
        x = urllib.request.urlopen("http://api.icndb.com/jokes/random?firstName=" + first_name + "&lastName=" + last_name)
        json_data = json.loads(x.read())
        joke = json_data['value']['joke']
        context = {'joke': joke}
        return render(request, 'index/index.html', context)


def portfolio(request):
    return render(request, 'index/portfolio.html')


def contact(request):
    if request.method == "POST":
        email_str = request.POST.get('email')
        subject_str = request.POST.get('subject')
        message_str = request.POST.get('message')

        if email_str == "" or subject_str == "" or message_str == "":
            return render(request, 'index/no_blanks.html')
        else:
            c = Contact(email=email_str, subject=subject_str, message=message_str)
            c.save()
            return render(request, 'index/thanks.html')
    else:
        return render(request, 'index/contact.html')
