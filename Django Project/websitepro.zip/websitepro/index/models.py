from django.db import models

# Create your models here.


class Student(models.Model):
    first_name = models.CharField(max_length=40)  # If we take a int then models.IntField and also we can leave CharField
    last_name = models.CharField(max_length=40)

    def __str__(self):
        # To display as the name in the admin page
        return self.first_name


class Contact(models.Model):
    email = models.EmailField()
    subject = models.CharField(max_length=100)
    message = models.TextField()

    def __str__(self):
        return self.email
